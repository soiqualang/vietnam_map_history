function setUpPage() {
    basicLoadTestSetup();
}