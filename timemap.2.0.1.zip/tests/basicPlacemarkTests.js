function setUpPage() {
    basicPlacemarkTestSetup();
}